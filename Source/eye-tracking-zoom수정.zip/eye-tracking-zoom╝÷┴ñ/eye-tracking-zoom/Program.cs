﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Tobii.Interaction;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Automation;
using System.Windows.Forms;
using System.Threading;
using System.Windows.Media;
//using Tobii.EyeX.Framework;
using EyeXFramework;


namespace eye_tracking_zoom
{
    class Program
    {
        static bool CanMoveCursor = false;
        static bool IsClick = false;
        static double x = 0;
        static double y = 0;

        [DllImport("user32.dll")]
        static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, int dwExtraInfo);

        static void Main(string[] args)
        {
            System.Threading.Timer t = new System.Threading.Timer((e) => { CanMoveCursor = true; }, null, 0, 20);
            var host = new Host();
            var gazePointDataStream = host.Streams.CreateGazePointDataStream();
            gazePointDataStream.GazePoint((gazePointX, gazePointY, _) =>
            {
                if (CanMoveCursor)
                {
                    mouse_event(0x0001, 1, 0, 0, 0);
                    x = x * 0.85 + gazePointX * 0.15;
                    y = y * 0.85 + gazePointY * 0.15;
                    Cursor.Position = new Point(Convert.ToInt32(x), Convert.ToInt32(y));
                    CanMoveCursor = false;
                }
            });

            var eyeXHost = new EyeXHost();
            eyeXHost.Start();
            var eyePositionDataStream = eyeXHost.CreateEyePositionDataStream();
            eyePositionDataStream.Next += (s, e) =>
            {
                if (IsClick == false && e.LeftEye.IsValid == true && e.RightEye.IsValid == false || )
                {
                    mouse_event(0x0002, 0, 0, 0, 0);
                    IsClick = true;
                }
                else if (IsClick == true && e.LeftEye.IsValid == true && e.RightEye.IsValid == true)
                {
                    mouse_event(0x0004, 0, 0, 0, 0);
                    IsClick = false;
                }
            };
            Console.Read();
        }


        public int Magnify(int mang)
        {


            return mang;
        }

        public double ZoomIn(double rate)
        {
            return rate;
        }



    }
}
