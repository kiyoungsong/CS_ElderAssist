﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Tobii.Interaction;
using EyeXFramework;

namespace noon
{

    public partial class MainForm : Form, IMessageFilter
    {

        [DllImport("user32.dll")]
        static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, int dwExtraInfo);
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        public const int WM_LBUTTONDOWN = 0x0201;

        static bool eyePointing = false;


        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool Wow64DisableWow64FsRedirection(ref IntPtr ptr);

        private HashSet<Control> controlsToMove = new HashSet<Control>();
        public MainForm()
        {
            InitializeComponent();
            Application.AddMessageFilter(this);

            controlsToMove.Add(this);
            IntPtr wow64Value = IntPtr.Zero;
            Wow64DisableWow64FsRedirection(ref wow64Value);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process[] handler = Process.GetProcessesByName("Magnify");
            if (handler.Length == 0)
            {
                ProcessStartInfo process = new ProcessStartInfo();
                process.FileName = @"Magnify.exe";
                button2.BackColor = Color.LightGray;
                Process.Start(process);
            }
            else
            {
                handler[0].Kill();
                button2.BackColor = Color.Transparent;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Process[] handler = Process.GetProcessesByName("Narrator");
            if (handler.Length == 0)
            {
                ProcessStartInfo process = new ProcessStartInfo();
                process.FileName = @"Narrator.exe";
                button3.BackColor = Color.LightGray;
                Process.Start(process);
            }
            else
            {
                button3.BackColor = Color.Transparent;
                handler[0].Kill();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Process[] handler = Process.GetProcessesByName("osk");
            if (handler.Length == 0)
            {
                ProcessStartInfo process = new ProcessStartInfo();
                process.FileName = @"osk.exe";
                button4.BackColor = Color.LightGray;
                Process.Start(process);
            }
            else
            {
                button4.BackColor = Color.Transparent;
                handler[0].Kill();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TopMost = !TopMost;
            if(TopMost)
            { button1.BackColor = Color.LightGray; }
            else
            { button1.BackColor = Color.Transparent; }
        }

        public bool PreFilterMessage(ref System.Windows.Forms.Message message)
        {
            if (message.Msg == WM_LBUTTONDOWN &&
                 controlsToMove.Contains(Control.FromHandle(message.HWnd)))
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
                return true;
            }
            return false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void eyePorintingButton_Click(object sender, EventArgs e)
        {
            eyePointing = !eyePointing;
            Process[] handler = Process.GetProcessesByName("noon2");
            if (handler.Length == 0 && eyePointing)
            {
                
                ProcessStartInfo process = new ProcessStartInfo();
                process.FileName = @"eye.exe";
                eyePorintingButton.BackColor = Color.LightGray;
                Process.Start(process);
            }
            else
            {
                handler[0].Kill();
                eyePorintingButton.BackColor = Color.Transparent;
            }

        }

        private void MainForm_Load(object sender, EventArgs eventArgs)
        { 
            if(Process.GetProcessesByName("Magnify").Length > 0)
            { button2.BackColor = Color.LightGray;}
            else{ button2.BackColor = Color.Transparent;}

            if (Process.GetProcessesByName("Narrator").Length > 0)
            { button3.BackColor = Color.LightGray; }
            else { button3.BackColor = Color.Transparent; }

            if (Process.GetProcessesByName("osk").Length > 0)
            { button4.BackColor = Color.LightGray; }
            else { button4.BackColor = Color.Transparent; }
        }
        
        /*private void checking(object sender, EventArgs eventArgs)
        {
            System.Threading.Timer t = new System.Threading.Timer((e) => { CanMoveCursor = true; }, null, 0, 20);
            var host = new Host();
            var gazePointDataStream = host.Streams.CreateGazePointDataStream();
            gazePointDataStream.GazePoint((gazePointX, gazePointY, _) =>
            {
                if (CanMoveCursor && eyePointing)
                {
                    mouse_event(0x0001, 1, 0, 0, 0);
                    x = x * 0.9 + gazePointX * 0.1;
                    y = y * 0.9 + gazePointY * 0.1;
                    Cursor.Position = new Point(Convert.ToInt32(x), Convert.ToInt32(y));
                    CanMoveCursor = false;
                }
            });

            var eyeXHost = new EyeXHost();
            eyeXHost.Start();
            var eyePositionDataStream = eyeXHost.CreateEyePositionDataStream();
            eyePositionDataStream.Next += (s, e) =>
            {
                if (IsClick == false && e.LeftEye.IsValid == true && e.RightEye.IsValid == false)
                {
                    mouse_event(0x0002, 0, 0, 0, 0);
                    IsClick = true;
                }
                else if (IsClick == true && e.LeftEye.IsValid == true && e.RightEye.IsValid == true)
                {
                    mouse_event(0x0004, 0, 0, 0, 0);
                    IsClick = false;
                }
            };
        }*/
    }
}
