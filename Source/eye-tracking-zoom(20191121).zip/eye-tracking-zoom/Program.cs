﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Tobii.Interaction;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Automation;
using System.Windows.Forms;
using System.Threading;
using System.Windows.Media;
//using Tobii.EyeX.Framework;
using EyeXFramework;
using System.Timers;
using System.IO;


namespace eye_tracking_zoom
{
    class Program
    {
        [DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();
        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        const int SW_HIDE = 0; // 숨기기
        const int SW_SHOW = 1; // 보이기


        static bool CanMoveCursor = false;
        static bool IsClick = false;
        static double x = 0;
        static double y = 0;

        //마우스 이벤트 값 가져오는 부분
        [DllImport("user32.dll")]
        static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, int dwExtraInfo);
        
        static void Main(string[] args)
        {
            /*FileStream ostrm;
            StreamWriter writer;
            TextWriter oldOut = Console.Out;*/

            /*try
            {
                ostrm = new FileStream("./GazePoint.txt", FileMode.OpenOrCreate, FileAccess.Write);
                writer = new StreamWriter(ostrm);
            }
            catch (Exception e)
            {
                Console.WriteLine("Cannot open Redirect.txt for writing");
                Console.WriteLine(e.Message);
                return;
            }*/

            Stopwatch wTime = new Stopwatch();
            double clickTime = 0;
            var handle = GetConsoleWindow();

            //ShowWindow(handle, SW_HIDE); // 콘솔숨기기
            ShowWindow(handle, SW_SHOW); // 콘솔보이기
            System.Threading.Timer t = new System.Threading.Timer((e) => { CanMoveCursor = true; }, null, 0, 20);
            var host = new Host();
            var gazePointDataStream = host.Streams.CreateGazePointDataStream();
            gazePointDataStream.GazePoint((gazePointX, gazePointY, _) =>
            {
                //파일 저장하는 부분경로
                string savePath = @"C:\gaze.txt";
                string txt;
                txt = $"Date: {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}, GazeX: {gazePointX}, GazeY: {gazePointY}\n";
                
                /*Console.SetOut(writer);*/
                /*if (CanMoveCursor)
                {
                    mouse_event(0x0001, 1, 0, 0, 0);
                    //마우스가 계속 흔들려 보정하는 부분
                    x = x * 0.85 + gazePointX * 0.15;
                    y = (y * 0.85 + gazePointY * 0.15) + 5;
                    //스크린의 24%이하 값으로 가게될경우 보정하는 부분
                    if (y <= Screen.PrimaryScreen.WorkingArea.Height * 0.24)
                    {
                        y = y - 8;
                        //마우스 위치를 잡아주는 부분
                        Cursor.Position = new Point(Convert.ToInt32(x), Convert.ToInt32(y));
                    }

                    Cursor.Position = new Point(Convert.ToInt32(x), Convert.ToInt32(y));
                    File.AppendAllText(savePath, txt);
                    CanMoveCursor = false;
                }*/
                File.AppendAllText(savePath, txt);
            });
            /*Console.SetOut(oldOut);
            writer.Close();
            ostrm.Close();*/

            var eyeXHost = new EyeXHost();
            eyeXHost.Start();
            var eyePositionDataStream = eyeXHost.CreateEyePositionDataStream();
            eyePositionDataStream.Next += (s, e) =>
            {
                if (IsClick == false && e.LeftEye.IsValid == true && e.RightEye.IsValid == false)
                {
                    wTime.Start();
                    clickTime = wTime.ElapsedMilliseconds / 1000;
                    //오른쪽 눈 감고 2초가 지나면 마우스가 누른 상태로 바뀜
                    if(clickTime >= 2)
                    {
                        mouse_event(0x0002, 0, 0, 0, 0);
                    }
                    else
                    {
                        mouse_event(0x0002, 0, 0, 0, 0);
                        mouse_event(0x0004, 0, 0, 0, 0);
                    }
                    
                    IsClick = true;
                }
                else if (IsClick == true && e.LeftEye.IsValid == true && e.RightEye.IsValid == true)
                {
                    wTime.Restart();
                    mouse_event(0x0004, 0, 0, 0, 0);
                    IsClick = false;
                }
            };
            Console.Read();
        }
    }
}
